<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>BookmarkItem</name>
    <message>
        <source>Open URL</source>
        <translation></translation>
    </message>
    <message>
        <source>Copy URL to clipboard</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ConfigWidget</name>
    <message>
        <source>Bookmarks files:</source>
        <translation></translation>
    </message>
    <message>
        <source>Add</source>
        <translation></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation></translation>
    </message>
    <message>
        <source>Use hostname in search</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Plugin</name>
    <message numerus="yes">
        <source>%n bookmarks indexed.</source>
        <translation>
            <numerusform>%n bookmark indexed.</numerusform>
            <numerusform>%n bookmarks indexed.</numerusform>
        </translation>
    </message>
    <message>
        <source>Select bookmarks file</source>
        <translation></translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation></translation>
    </message>
</context>
</TS>
