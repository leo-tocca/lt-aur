# Albert plugin: Chromium
