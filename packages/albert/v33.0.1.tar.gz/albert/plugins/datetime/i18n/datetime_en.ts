<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ConfigWidget</name>
    <message>
        <source>Show date and time on empty query</source>
        <translation></translation>
    </message>
    <message>
        <source>The &apos;date and time&apos; extension provides the items *date*, *time*, *unix* and *utc*. It also converts unix timestamps (numbers) to local time.</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>DateTimeItemBase</name>
    <message>
        <source>Date</source>
        <translation></translation>
    </message>
    <message>
        <source>Unix time</source>
        <translation></translation>
    </message>
    <message>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <source>UTC date and time</source>
        <translation></translation>
    </message>
    <message>
        <source>Date and time</source>
        <translation></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation></translation>
    </message>
    <message>
        <source>Copy and paste</source>
        <translation></translation>
    </message>
    <message>
        <source>Date and time from unix time</source>
        <translation></translation>
    </message>
</context>
</TS>
