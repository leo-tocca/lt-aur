# Albert plugin: Albert

## Features

Provides application related items:

- Settings
- Quit
- Restart
- Cache directory
- Config directory
- Data directory
