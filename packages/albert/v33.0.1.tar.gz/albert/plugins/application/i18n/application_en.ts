<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Plugin</name>
    <message>
        <source>Cache location</source>
        <translation></translation>
    </message>
    <message>
        <source>Albert cache location</source>
        <translation></translation>
    </message>
    <message>
        <source>Config location</source>
        <translation></translation>
    </message>
    <message>
        <source>Albert config location</source>
        <translation></translation>
    </message>
    <message>
        <source>Data location</source>
        <translation></translation>
    </message>
    <message>
        <source>Albert data location</source>
        <translation></translation>
    </message>
    <message>
        <source>Open</source>
        <translation></translation>
    </message>
    <message>
        <source>Open in terminal</source>
        <translation></translation>
    </message>
    <message>
        <source>Quit</source>
        <translation></translation>
    </message>
    <message>
        <source>Quit Albert</source>
        <translation></translation>
    </message>
    <message>
        <source>Restart</source>
        <translation></translation>
    </message>
    <message>
        <source>Restart Albert</source>
        <translation></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation></translation>
    </message>
    <message>
        <source>Albert settings</source>
        <translation></translation>
    </message>
</context>
</TS>
