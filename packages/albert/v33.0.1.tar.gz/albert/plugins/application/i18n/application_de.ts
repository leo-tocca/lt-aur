<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>Plugin</name>
    <message>
        <source>Cache location</source>
        <translation>Cache Verzeichnis</translation>
    </message>
    <message>
        <source>Albert cache location</source>
        <translation>Albert Cache Verzeichnis</translation>
    </message>
    <message>
        <source>Config location</source>
        <translation>Konfigurationsverzeichnis</translation>
    </message>
    <message>
        <source>Albert config location</source>
        <translation>Albert Konfigurationsverzeichnis</translation>
    </message>
    <message>
        <source>Data location</source>
        <translation>Datenverzeichnis</translation>
    </message>
    <message>
        <source>Albert data location</source>
        <translation>Albert Datenverzeichnis</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <source>Open in terminal</source>
        <translation>In Terminal öffnen</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Beenden</translation>
    </message>
    <message>
        <source>Quit Albert</source>
        <translation>Albert beenden</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Neu starten</translation>
    </message>
    <message>
        <source>Restart Albert</source>
        <translation>Albert neu starten</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <source>Albert settings</source>
        <translation>Albert Einstellungen</translation>
    </message>
</context>
</TS>
