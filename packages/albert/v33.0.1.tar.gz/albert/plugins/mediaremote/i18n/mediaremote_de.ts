<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>Plugin</name>
    <message>
        <source>Play</source>
        <translation>Wiedergabe</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Nächster</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation>Vorheriger</translation>
    </message>
</context>
</TS>
