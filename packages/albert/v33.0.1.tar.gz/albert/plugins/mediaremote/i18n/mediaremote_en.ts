<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Plugin</name>
    <message>
        <source>Play</source>
        <translation></translation>
    </message>
    <message>
        <source>Pause</source>
        <translation></translation>
    </message>
    <message>
        <source>Next</source>
        <translation></translation>
    </message>
    <message>
        <source>Previous</source>
        <translation></translation>
    </message>
</context>
</TS>
