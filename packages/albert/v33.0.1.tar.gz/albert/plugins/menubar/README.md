# Albert plugin: Menu bar
