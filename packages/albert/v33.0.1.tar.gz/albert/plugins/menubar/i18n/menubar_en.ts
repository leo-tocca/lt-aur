<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Plugin</name>
    <message>
        <source>Activate</source>
        <translation></translation>
    </message>
    <message>
        <source>The menu bar plugin requires accessibility permissions to access the menu items of the focused application.

macOS requires you to enable this manually in system settings. Please toggle Albert in the accessibility settings, which will appear after you close this dialog.</source>
        <translation></translation>
    </message>
</context>
</TS>
