<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>Plugin</name>
    <message>
        <source>Activate</source>
        <translation>Aktivieren</translation>
    </message>
    <message>
        <source>The menu bar plugin requires accessibility permissions to access the menu items of the focused application.

macOS requires you to enable this manually in system settings. Please toggle Albert in the accessibility settings, which will appear after you close this dialog.</source>
        <translation>Das Menüleisten-Plugin benötigt Funktionen der Bedienungshilfe für den Zugriff auf die Menüelemente der aktiven Anwendung.

macOS erfordert, dass dies manuell in den Systemeinstellungen erlaubt wird. Bitte schalten Sie Albert in den Einstellungen für Bedienungshilfen frei, die nach dem Schließen dieses Dialogs erscheinen.</translation>
    </message>
</context>
</TS>
