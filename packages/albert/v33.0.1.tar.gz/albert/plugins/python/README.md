# Albert plugin: Python plugins
