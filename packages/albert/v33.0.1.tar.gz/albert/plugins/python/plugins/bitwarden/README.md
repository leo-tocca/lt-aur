# Albert plugin: Bitwarden

⚠️This plugin has no maintainers and will be removed from the official plugins if it breaks.

Please consider becoming a maintainer.

