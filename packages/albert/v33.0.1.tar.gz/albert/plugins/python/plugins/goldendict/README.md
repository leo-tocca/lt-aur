# Albert plugin: GoldenDict

⚠️This plugin has no maintainers and will be removed from the official repository if it breaks.

Please consider becoming a maintainer.

