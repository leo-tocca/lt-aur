<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Plugin</name>
    <message>
        <source>Person</source>
        <translation></translation>
    </message>
    <message>
        <source>Organization</source>
        <translation></translation>
    </message>
    <message>
        <source>Open in contacts app</source>
        <translation></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation></translation>
    </message>
    <message>
        <source>Copy phone number &apos;%1&apos;</source>
        <translation></translation>
    </message>
    <message>
        <source>Call phone number &apos;%1&apos;</source>
        <translation></translation>
    </message>
    <message>
        <source>iMessage to &apos;%1&apos;</source>
        <translation></translation>
    </message>
    <message>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <source>Copy email address &apos;%1&apos;</source>
        <translation></translation>
    </message>
    <message>
        <source>Send mail to &apos;%1&apos;</source>
        <translation></translation>
    </message>
    <message>
        <source>Website</source>
        <translation></translation>
    </message>
    <message>
        <source>Copy website address &apos;%1&apos;</source>
        <translation></translation>
    </message>
    <message>
        <source>Open website &apos;%1&apos;</source>
        <translation></translation>
    </message>
    <message>
        <source>The application is not authorized to access contacts.</source>
        <translation></translation>
    </message>
    <message>
        <source>The user denied access to contacts.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
